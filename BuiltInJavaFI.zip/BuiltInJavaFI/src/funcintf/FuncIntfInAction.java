
package funcintf;

import java.util.Arrays;
import java.util.function.*;

public class FuncIntfInAction {
    
    static int[] get10IntRand(){
        int[] arr = new int[10];
        for(int i=0;i<10;i++){
            arr[i] = (int) Math.round(10*Math.random());
        }
        return arr;
    }
    
    static float get_avg(int[] arr){
        float sum=0;
        for(int elm: arr) sum+=elm;
        return sum/arr.length;       
    }
    
    static boolean ifContainsNumber(int [] arr, int numb){
        for(int elm: arr)
            if(elm == numb) return true;
        return false;
    }
    
    static boolean ifLastHasNumber(int [] arr, int numb){
        return arr[arr.length-1] == numb;
    }
    
    public static void main(String[] args) {
        Supplier<int[]> get10rand = () -> get10IntRand();
        Consumer<int[]> prt_arr = (myarr) -> System.out.println(Arrays.toString(myarr));
        int [] my_rand_arr = get10rand.get();
        prt_arr.accept(my_rand_arr);
        
        Predicate<int[]> ifMoreThan5 = (myarr)-> get_avg(myarr)> 5;
        System.out.println("Average of random array: "+get_avg(my_rand_arr));
        System.out.println("Average of random array > 5: "+ifMoreThan5.test(my_rand_arr));
        
        BiPredicate<int[],Integer> ifContNumb = (myarr,numb) -> ifContainsNumber(myarr,numb);
        BiPredicate<int[],Integer> ifLastNumb = (myarr,numb) -> ifLastHasNumber(myarr, numb);
        BiPredicate<int[],Integer> ifHasNumbAndLastNumb = ifContNumb.and(ifLastNumb);
        
        System.out.println("If contains 5: "+ifContNumb.test(my_rand_arr,5));
        System.out.println("If Last is 4: "+ifLastNumb.test(my_rand_arr,4));
        System.out.println("If 5 is there and last: "+ifHasNumbAndLastNumb.test(my_rand_arr,5));
    }
}
